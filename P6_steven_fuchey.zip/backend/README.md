# préparation des fichiers

modifier le ".env.model" en ".env" et ajoutez vos information dedans pour vous connecter a votre propre base de donnée mongoDB

ouvrez un terminal et placez vous dans backend et faite "npm install" puis "nodemon server"
